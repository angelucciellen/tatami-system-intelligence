# vX Session Companion — Replit Setup

## What this is
Real-time trading session partner for the vX Rhythm Engine.
- Pre-session brief (macro calendar + regime context)
- Pattern cross-reference against P1–P18
- Screenshot analysis — drop any TradingView chart
- Research observation logger
- Session log (builds your memory layer over time)

## Deploy on Replit

### 1. Create a new Replit
- Go to replit.com → New Repl
- Choose **Python** template
- Name it: `vx-session-companion`

### 2. Upload these files
Upload all files in this folder to your Replit:
- `server.py`
- `index.html`
- `requirements.txt`
- `.replit`

### 3. Add your API key as a Secret
In Replit → Tools → Secrets:
- Key: `ANTHROPIC_API_KEY`
- Value: your `sk-ant-...` key

Then in `server.py` the client will pick it up automatically via environment variable. Or you can enter it directly in the app's sidebar — it's not stored anywhere.

### 4. Run
Click **Run** in Replit. The server starts on port 5000.
Open the Webview — that's your Companion URL.

## Usage

### Pre-session brief
Click `◈ GC · London` or type:
```
Session brief — GC 5m · London session
```

### Pattern analysis
Drop a TradingView screenshot into the drop zone.
The Companion reads the chart and cross-references against P1–P18.

### Research log
```
Research obs — [describe what you noticed]
```
Companion classifies obs_type and produces a copy-paste tagger note.

### Ask anything
Any question about the GT, patterns P1–P18, locked decisions, tagger rules.

## Session logs
Every conversation is logged to `session_logs/` as `.jsonl` files.
These are private, local to your Replit. The seed of the memory layer.

## Costs
Each message uses Claude Sonnet (~1500 tokens output max).
Approximate cost: $0.02–0.05 per session brief or pattern analysis.
$10 of API credits = hundreds of sessions.

---
vX Rhythm Engine™ · Session Companion v1.0 · GT v1.11 · Palette v3.1
