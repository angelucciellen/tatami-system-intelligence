"""
vX Session Companion — Backend Server
Flask proxy for Anthropic API — solves CORS for browser clients
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import anthropic
import json
import os
from datetime import datetime
from pathlib import Path

app = Flask(__name__, static_folder='.')
CORS(app)

LOGS_DIR = Path('session_logs')
LOGS_DIR.mkdir(exist_ok=True)

GT_CONTEXT = """You are the vX Session Companion — a real-time trading session partner for the vX Rhythm Engine project.

CREATOR CONTEXT (read first — critical):
The creator is 2e (twice-exceptional) — exceptional pattern recognition, harder working memory. They may forget macro events. Surface one thing at a time. Never present ten things simultaneously. Be direct and concise. Always check the economic calendar at session start and flag any CPI, FOMC, NFP, or major macro event proactively — this is the single most important coaching function.

YOUR KNOWLEDGE BASE — vX Ground Truth v1.11:

INSTRUMENT: GC (Gold Futures) 5m primary, NQ (Nasdaq) 5m secondary.
SESSION WINDOWS (UTC+9): Tokyo 09:00–15:00 · Gap 15:00–16:00 (skip) · London 16:00–22:00 · NY 22:00–05:00

CURRENT STATUS:
- 150 events total. B1 (E1-50) = FILTERED_DISCOVERY (cherry-picked, excluded from primary LED rate).
- B2+B3 (E51-150) = PRIMARY. Honest baseline: ~48% LED.
- Batch 3 locked. Batch 4 next.
- Exhaustion anomaly: dropped 66.7%→50.0% — monitor in B4.
- MIXED sync finding: 70.8% LED at n=24 — directional only, not confirmed.

ENGINE — 7 STATES:
TRAVERSAL (#00BFA5) — active directional move in channel
EXPANSION (#26C6DA) — burst breakout momentum
COMPRESSION (#4A7EC7) — coil before release
EXHAUSTION (#E8E8F0) — move spent, fading
NEUTRAL (#A0AAB9) — ambient, no edge / Equilibrium Drift
FAILED (#9575CD) — commitment broke / Failed Traversal
DISTORTION — Volatility Distortion — macro event override

4 SCORES (0-100): Quality (Q) · Compress (C) · Expansion (X) · Exhaust (E)
GC/NQ thresholds: TRAV/COMP/EXP ≥55, EXHAUST ≥60

SYNC LABELS: STRONG_SYNC · MIXED · CONFLICT · TRANSITION
CONTEXT: MACRO_ALIGNED · DIRECTION_CONFLICT · PULLBACK_IN_TREND · COUNTER_TREND · MIXED

PALETTE v3.1 (locked 2026-06-02):
Traversal=#00BFA5 · Expansion=#26C6DA · Compression=#4A7EC7
Exhaustion=#E8E8F0 · Neutral=#A0AAB9 · Failed=#9575CD · PRIME=#D4A853

PATTERN LIBRARY (P1–P18):
P3: Zone density ≥10 — 70.8% LED above vs 53.3% below. Strongest single filter.
P5: Mid-channel WRONG — TRAVERSAL Q60-70 mid-channel = WRONG
P7: Quality-Rail interaction — TRAVERSAL Q≥55 at rail = LED; Q60-70 mid = WRONG
P8: Failed Traversal quality inversion — Q>50 on FAILED = suspect classification
P9A: Exhaustion Type A — EXHAUST Q≤40 + exhaust≥60 = WRONG
P9B: Exhaustion Type B — both HTFs aligned prior direction = WRONG
P11: Post-move trap — large prior move + wide channel = WRONG
P12: Pre-signal coil — 2-4 bar ATR contraction before signal = higher LED
P13: STRONG_SYNC visual signature — elevated LED (n=8, insufficient data)
P14: Failed Traversal at HTF structural level — cleanest LED reversals
P15: Pre-signal coil presence — confirmed as LED predictor
P17: Expansion CONFLICT anomaly — EXPANSION + CONFLICT sync = structural contradiction
P18: Cascade sequence — cascade YES = highest MFE outcomes

FILTERS F1-F12:
F1: Rail proximity (rail_zone ≠ MID)
F2: Pre-signal compression (pre-signal coil)
F3: Zone density ≥10
F4: Failed Traversal Q≤50
F5: Exhaustion dual-condition (exhaust≥60 AND prior Q≥45)
F6: NY session only
F7: Exclude Direction Conflict + TRANSITION
F8: Exclude Quality 61-70 on TRAVERSAL
F9: HTF structural level (htf_rail_align=YES)
F10: Zone type diversity HIGH
F11: MIXED sync only
F12: Exclude CONFLICT sync

COMPOSITE SIGNAL — ◆ PRIME (#D4A853):
Fires when ALL conditions simultaneously met (confirmed in Phase B).
Additive to state badge — never replaces it. Fires rarely. Always prefix ◆.

TAGGER v4 FIELDS:
ltf_state · ltf_dir · quality · compress · expansion · exhaust
htf1_state · htf1_dir · htf2_state · htf2_dir · sync · context · memory
rail_zone (UPPER_RAIL/MID_CHANNEL/LOWER_RAIL) · mae_atr · cascade
htf_rail_align (YES/NO) · zone_diversity (LOW/MEDIUM/HIGH)
obs_type (PRIMARY/HTF_STRUCTURE/INTRA_STATE)
tag (LED/WRONG/CONFIRMED/LAGGED) · outcome_dir · outcome_atr · notes

OBS_TYPE RULES:
PRIMARY — mechanical state change, counts in LED rate
HTF_STRUCTURE — structural observation at HTF rail, research sub-dataset
INTRA_STATE — sync/context change inside active state, research sub-dataset
Max 5 research observations per 25-event sitting.

SKIP WINDOW RULE: 6-bar skip after signal.
Significant transitions (immediate tag): Traversal→Exhaustion, Compression→Expansion, Failed→Exhaustion, direction reversal.

LOCKED DECISIONS (GT v1.11):
- Go/no-go: 63% combined filter, n≥300 passing, ±4pts stable across 4 batches, both instruments ≥60%
- GC launches first. NQ needs 200-300 additional independent events.
- B1 = FILTERED_DISCOVERY. Honest baseline B2+B3 = ~48%.
- Minimum n per state for Phase B: 30.
- S3 sensitivity test always required. S1/S2 conditional.
- Volume layer: A2 (deferred). v0.5 has 4 layers only.
- PRIME signal: ◆ PRIME · gold #D4A853
- GT publication: methodology summary only, after Phase B go + IP docs complete.
- IP archive: do immediately (export GT + email to self).

GC MARKET STRUCTURE:
- London (16:00-22:00 UTC+9): primary trend-setting session
- NY (22:00-05:00 UTC+9): momentum continuation/reversal
- Tokyo (09:00-15:00 UTC+9): often coil/drift dominant
- Volume excludes OTC gold and ETF arbitrage flows
- Channel structures follow fibonacci relationships

STATISTICAL STANDARDS:
- Minimum n=30 per state for Phase B conclusions
- LED rate is NOT a win rate — it measures MFE≥1.0 ATR within 6 bars
- Never declare a pattern valid below minimum n
- Never recommend trades — identify patterns and conditions only

RESPONSE RULES:
1. NEVER say "this looks like a good trade" or give directional opinions
2. Pre-session brief = one focused paragraph with macro + regime + one pattern watch
3. Pattern cross-reference = checklist of conditions + tagger note block
4. Research log = obs_type + copy-paste note
5. When analyzing a chart image: identify state badges, channel structure, rail position, zone density
6. Always honest about data limits — say "directional only" or "insufficient n" when needed
7. Macro events get flagged prominently — never buried
8. End pattern responses with a tagger note block formatted as:
   ```tagger-note
   [field]: [value] · [field]: [value] ...
   ```"""

MODE_INSTRUCTIONS = {
    'brief': """PRE-SESSION BRIEF MODE.
Use the web_search tool to check today's economic calendar for GC/NQ relevant events (CPI, FOMC, NFP, Fed speakers, Treasury auctions).
Structure your response:
1. Session + date + time
2. Any macro warnings PROMINENTLY (flag within 2 bars of session window)
3. Current regime context from GT (last batch B3: GC Traversal UP, MIXED sync)
4. ONE pattern to watch this session
Keep it tight — one paragraph per section, no more.""",

    'pattern': """PATTERN ANALYSIS MODE.
When given a chart image or signal description:
1. Identify matching patterns from P1–P18
2. Show a checklist: ✓ confirmed / ⚠ check needed / ✗ missing
3. State obs_type recommendation
4. End with a tagger note block in this format:
```tagger-note
obs_type: PRIMARY · [fields and values] · notes: [pattern refs]
```
Do NOT give directional opinions.""",

    'research': """RESEARCH LOG MODE.
For observations that aren't mechanical state changes:
1. Classify as HTF_STRUCTURE or INTRA_STATE and explain why
2. Link to relevant open question (Q-A through Q-L) if applicable
3. Provide a tagger note block:
```tagger-note
obs_type: HTF_STRUCTURE · [or INTRA_STATE] · notes: [description] · relates to: [Q-X]
```""",

    'ask': """ASK ANYTHING MODE.
Answer questions about patterns P1–P18, tagging rules, locked decisions from GT v1.11, statistical findings, or tagger field usage. Be direct. Reference specific GT sections when relevant."""
}


@app.route('/')
def index():
    return send_from_directory('.', 'index.html')


@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    api_key = data.get('api_key', '').strip()
    messages = data.get('messages', [])
    mode = data.get('mode', 'ask')
    session_id = data.get('session_id', 'default')

    if not api_key:
        return jsonify({'error': 'API key required'}), 400
    if not messages:
        return jsonify({'error': 'No messages provided'}), 400

    system_prompt = GT_CONTEXT + '\n\n' + MODE_INSTRUCTIONS.get(mode, MODE_INSTRUCTIONS['ask'])

    try:
        client = anthropic.Anthropic(api_key=api_key)

        # Build message list - handle image content
        api_messages = []
        for msg in messages:
            if isinstance(msg.get('content'), list):
                api_messages.append(msg)
            else:
                api_messages.append({
                    'role': msg['role'],
                    'content': msg['content']
                })

        response = client.messages.create(
            model='claude-sonnet-4-20250514',
            max_tokens=1500,
            system=system_prompt,
            messages=api_messages
        )

        assistant_text = ''.join(
            block.text for block in response.content
            if block.type == 'text'
        )

        # Log session
        log_session(session_id, messages[-1], assistant_text, mode)

        return jsonify({
            'content': assistant_text,
            'mode': mode
        })

    except anthropic.AuthenticationError:
        return jsonify({'error': 'Invalid API key — check your sk-ant-... key'}), 401
    except anthropic.RateLimitError:
        return jsonify({'error': 'Rate limit hit — wait a moment and try again'}), 429
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def log_session(session_id, user_msg, assistant_text, mode):
    """Append to session log — the seed of the memory layer."""
    log_file = LOGS_DIR / f"{session_id}.jsonl"
    entry = {
        'timestamp': datetime.now().isoformat(),
        'mode': mode,
        'user': user_msg.get('content', '') if isinstance(user_msg.get('content'), str) else '[image+text]',
        'assistant': assistant_text[:500],  # truncate for log size
    }
    with open(log_file, 'a') as f:
        f.write(json.dumps(entry) + '\n')


@app.route('/api/logs/<session_id>', methods=['GET'])
def get_logs(session_id):
    """Return session log entries."""
    log_file = LOGS_DIR / f"{session_id}.jsonl"
    if not log_file.exists():
        return jsonify({'entries': []})
    entries = []
    with open(log_file, 'r') as f:
        for line in f:
            try:
                entries.append(json.loads(line.strip()))
            except:
                pass
    return jsonify({'entries': entries[-50:]})  # last 50


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
