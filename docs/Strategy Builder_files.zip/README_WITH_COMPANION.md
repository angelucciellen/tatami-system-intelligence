# TATAMI Platform — Complete System with Session Companion

**Unified behavioral market intelligence platform: Research + Batch Pipeline + Live Session Partner**

Three integrated layers covering everything from pre-session intelligence to batch validation to persistent data management.

---

## What You Have

### Layer 1 — Live Session Intelligence
Pre-tagging preparation dashboard
- Macro events calendar
- Session windows (Tokyo/London/NY)
- Pre-session checklist (12 items from GT v1.25)
- Pattern quick reference (P1–P23)
- Ground Truth status

### Session Companion ⭐ (NEW)
Real-time partner during trading analysis — **9 interactive modes**:

1. **Session Brief** — Calendar + macro context before TradingView
2. **Pattern Analysis** — Upload chart, get P1–P23 checklist + tagger note
3. **Research Log** — Log RESEARCH_OBS (Drift, Rail Cycle, Liquidity Sweep)
4. **Ask Anything** — Direct GT rules/patterns/decisions
5. **Session Findings** — Auto-format findings for GT Decision Log
6. **Tagger Audit** — Paste CSV, get field error report
7. **Pattern Tracker** — Match observations to Q-A/Q-W + candidates
8. **Decision Journal** — Log methodology decision for GT
9. **Phase B Readiness** — Calculate current go/no-go status

Each mode uses Ground Truth v1.25 as its knowledge base.

### Layer 2 — Batch Pipeline
Post-tagging automation with three agents + approval gates:
1. **Batch Analyzer** — Statistical audit (LED rates, anomalies)
2. **Pattern Miner** — Screenshot analysis (P1–P23 matching)
3. **GT Keeper** — Version diff proposal (draft GT v1.26)

### Layer 3 — Intelligence Store
Persistent queryable database:
- **Event Explorer** — Filter/query 337+ locked events
- **Pattern Library** — P1–P23 with examples + status
- **GT Versions** — Current v1.25 + full history
- **Co-Pilot Training** — Session Companion sessions logged for fine-tuning

---

## Architecture

```
TATAMI Platform (Flask + SQLite)
│
├─ Layer 1: Live Session Dashboard
│  └─ Pre-tagging intelligence + checklists
│
├─ Session Companion (9 modes)
│  └─ Real-time Claude partner during analysis
│
├─ Layer 2: Batch Pipeline
│  ├─ Batch Analyzer
│  ├─ Pattern Miner
│  └─ GT Keeper
│
└─ Layer 3: Intelligence Store
   ├─ Event Database (queryable)
   ├─ Pattern Library
   ├─ GT Versions
   └─ Co-Pilot Training Data
```

---

## Access Points

| URL | What | Purpose |
|-----|------|---------|
| `/` | Dashboard | All three layers overview |
| `/pipeline` | Batch Pipeline | Processing interface |
| `/companion` | Session Companion | 9 interactive modes |

---

## Workflow

### Before Tagging
1. Go to `/` (dashboard)
2. Review macro events, session windows, checklist
3. Check pattern quick reference
4. If you have a specific question → click "Session Companion" button

### During Analysis
1. Open Session Companion (`/companion`)
2. Pick a mode:
   - **Pattern Analysis** → upload chart, get checklist
   - **Ask Anything** → GT rule questions
   - **Research Log** → log special observations
   - **Tagger Audit** → check CSV before export

### After Tagging (Batch Processing)
1. Go to `/pipeline`
2. Upload ZIP from Tagger
3. Run Batch Analyzer → Pattern Miner → GT Keeper
4. All stages lock with creator approval

### Post-Batch Research
1. Dashboard → Layer 3
2. Query event database
3. Browse pattern library
4. Check Co-Pilot training accumulation

---

## Session Companion Modes Explained

### Mode: Session Brief
**Best for**: Before opening TradingView
- Input: (none — auto-loads from calendar)
- Output: Macro events, session window status, key pattern reminders
- Logs: No

### Mode: Pattern Analysis
**Best for**: Testing a chart setup
- Input: "I see compression Q=58, HTF aligned, STRONG_SYNC"
- Output: P1–P23 checklist, tagger note block, confidence assessment
- Logs: Yes (for training)

### Mode: Ask Anything
**Best for**: GT rule questions
- Input: "What's the rule on EXHAUSTION Q<40?"
- Output: Direct rule answer, examples, edge cases
- Logs: Yes (for training)

### Mode: Research Log
**Best for**: Documenting non-PRIMARY observations
- Input: "Saw drift behavior at rail, bars 12-14"
- Output: Formatted obs_type, note convention, pattern matches
- Logs: Yes (with obs_type tagged)

### Mode: Session Findings
**Best for**: End-of-session summary
- Input: "Traversal was strong, 61% LED, London session weak"
- Output: Auto-formatted findings block for GT Decision Log
- Logs: Yes (as decision candidate)

### Mode: Tagger Audit
**Best for**: CSV validation before ZIP export
- Input: (paste CSV rows or describe data)
- Output: Field errors, missing values, logic issues, outliers
- Logs: No

### Mode: Pattern Tracker
**Best for**: Connecting observations to research questions
- Input: "Notice zone density varies by session"
- Output: Matches to Q-A through Q-W, candidate patterns, data needs
- Logs: Yes (as research observation)

### Mode: Decision Journal
**Best for**: Locking methodology decisions
- Input: "Exclude Dir Conflict + TRANSITION on GC only (reversed on NQ)"
- Output: Formatted Decision Log entry, GT section, action item
- Logs: Yes (added to GT Decision Log)

### Mode: Phase B Readiness
**Best for**: Checking progress to go/no-go
- Input: (none — reads from database)
- Output: Event counts, state coverage, filter performance, batches remaining
- Logs: No

---

## Database Schema

| Table | Purpose |
|-------|---------|
| `batches` | Batch metadata + pipeline status |
| `events` | All 25 tagger fields (locked CSVs) |
| `analyses` | Agent reports (JSON) |
| `patterns` | P1–P23 library + candidates |
| `copilot_training` | Session Companion sessions logged |

All Session Companion interactions are logged to `copilot_training` for future fine-tuning.

---

## API Endpoints

### Dashboard & Layers
```
GET  /api/session/macro-events
GET  /api/session/windows
GET  /api/patterns/library
GET  /api/gt/current
GET  /api/checklist/pre-session
```

### Session Companion
```
GET  /api/companion/modes                # List all 9 modes
POST /api/companion/chat                 # Send message to mode
POST /api/companion/log                  # Log session for training
```

### Batch Pipeline
```
POST /api/upload-batch
POST /api/batch/<id>/analyze
POST /api/batch/<id>/pattern-mine
POST /api/batch/<id>/keeper
GET  /api/batch/<id>/status
POST /api/batch/<id>/approve/<stage>
GET  /api/batches
```

### Intelligence Store
```
GET  /api/patterns/with-screenshots
POST /api/events/query
GET  /api/gt/versions
POST /api/copilot/log-session
GET  /api/copilot/training-stats
POST /api/filter-test
```

---

## File Structure

```
tatami-platform/
├── app.py                           # Flask server (all endpoints)
├── database.py                      # SQLite schema
├── requirements.txt                 # Dependencies
├── .replit                          # Replit config
│
├── agents/
│   ├── batch_analyzer.py            # Agent 1
│   ├── pattern_miner.py             # Agent 2
│   └── gt_keeper.py                 # Agent 3
│
└── static/
    ├── dashboard.html               # Layer 1 + 2 + 3
    ├── index.html                   # Pipeline detail
    └── companion.html                # Session Companion
```

---

## Deploy

1. Create new Replit project (Python)
2. Upload all files
3. Set secret: `ANTHROPIC_API_KEY=sk-ant-...`
4. Click Run
5. Access:
   - **Main dashboard**: `https://your-replit.repl.co/`
   - **Session Companion**: `https://your-replit.repl.co/companion`
   - **Pipeline**: `https://your-replit.repl.co/pipeline`

---

## Test Checklist

- [ ] Dashboard loads (macro events, session windows)
- [ ] Session Companion opens with 9 mode cards
- [ ] "Ask Anything" mode responds with GT rules
- [ ] "Pattern Analysis" mode accepts input
- [ ] Session responses logged to database
- [ ] Export small batch from Tagger
- [ ] Upload ZIP to pipeline
- [ ] All three agents run successfully
- [ ] Query event database in Layer 3
- [ ] Co-Pilot stats show training data accumulating

---

## Key Features

✓ **Session Companion** — 9 interactive modes with Ground Truth v1.25  
✓ **All three agents** — Analyzer, Miner, Keeper  
✓ **vX brand theming** — Dark, institutional  
✓ **Pattern library** — P1–P23 with status badges  
✓ **Event querying** — Filter by any field  
✓ **Co-Pilot training** — Automatic session logging  
✓ **GT versioning** — Track all changes  
✓ **UTC+9 sessions** — Live window tracking  
✓ **Approval gates** — Creator review at each stage  

---

**Platform Status**: Complete, production-ready  
**Session Companion**: Integrated with 9 modes, GT v1.25  
**Last Updated**: 2026-06-14  
**Phase**: C (validation)