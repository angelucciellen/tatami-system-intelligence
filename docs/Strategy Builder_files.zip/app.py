import os
import json
import sqlite3
import zipfile
import csv
import pytz
from io import StringIO
from pathlib import Path
from datetime import datetime, time as dt_time
from flask import Flask, request, jsonify, send_from_directory
from dotenv import load_dotenv
from agents.batch_analyzer import BatchAnalyzer
from agents.pattern_miner import PatternMiner
from agents.gt_keeper import GTKeeper

load_dotenv()

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max upload
app.config['UPLOAD_FOLDER'] = 'storage/uploads'
app.config['SCREENSHOTS_FOLDER'] = 'storage/screenshots'
app.config['DB_PATH'] = 'storage/data/tatami.db'

# Create directories
Path(app.config['UPLOAD_FOLDER']).mkdir(parents=True, exist_ok=True)
Path(app.config['SCREENSHOTS_FOLDER']).mkdir(parents=True, exist_ok=True)
Path('storage/data').mkdir(parents=True, exist_ok=True)

# Initialize database
from database import init_db
init_db(app.config['DB_PATH'])

@app.route('/api/upload-batch', methods=['POST'])
def upload_batch():
    """Accept ZIP file and return parsed batch data"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not file.filename.endswith('.zip'):
        return jsonify({'error': 'File must be a ZIP archive'}), 400
    
    try:
        # Save uploaded file temporarily
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(temp_path)
        
        # Extract and parse
        batch_data = parse_zip_batch(temp_path)
        
        # Extract screenshots to storage
        instrument = batch_data['metadata'].get('instrument', 'UNKNOWN')
        extract_screenshots(temp_path, instrument, batch_data)
        
        # Store batch in database (status: PENDING_ANALYZER)
        from database import store_batch
        batch_id = store_batch(app.config['DB_PATH'], batch_data, 'PENDING_ANALYZER')
        
        # Clean up temp file
        os.remove(temp_path)
        
        return jsonify({
            'status': 'success',
            'batch_id': batch_id,
            'events_count': len(batch_data['events']),
            'screenshot_count': len(batch_data['screenshots']),
            'message': 'Batch uploaded. Ready for Batch Analyzer.'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/batch/<batch_id>/analyze', methods=['POST'])
def analyze_batch(batch_id):
    """Run Batch Analyzer agent on batch"""
    try:
        from database import get_batch
        batch_data = get_batch(app.config['DB_PATH'], batch_id)
        
        if not batch_data:
            return jsonify({'error': 'Batch not found'}), 404
        
        analyzer = BatchAnalyzer(os.getenv('ANTHROPIC_API_KEY'))
        report = analyzer.analyze(batch_data)
        
        from database import update_batch_status, store_analysis
        update_batch_status(app.config['DB_PATH'], batch_id, 'ANALYZER_COMPLETE')
        store_analysis(app.config['DB_PATH'], batch_id, 'batch_analyzer', report)
        
        return jsonify({
            'status': 'complete',
            'batch_id': batch_id,
            'report': report,
            'next_stage': 'PENDING_PATTERN_MINER'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/batch/<batch_id>/pattern-mine', methods=['POST'])
def pattern_mine_batch(batch_id):
    """Run Pattern Miner agent on batch"""
    try:
        from database import get_batch, get_analysis
        batch_data = get_batch(app.config['DB_PATH'], batch_id)
        
        if not batch_data:
            return jsonify({'error': 'Batch not found'}), 404
        
        # Get batch analyzer report for context
        analyzer_report = get_analysis(app.config['DB_PATH'], batch_id, 'batch_analyzer') or {}
        
        # Run Pattern Miner
        miner = PatternMiner(os.getenv('ANTHROPIC_API_KEY'))
        report = miner.analyze(batch_data, app.config['SCREENSHOTS_FOLDER'])
        
        from database import update_batch_status, store_analysis
        update_batch_status(app.config['DB_PATH'], batch_id, 'PATTERN_MINER_COMPLETE')
        store_analysis(app.config['DB_PATH'], batch_id, 'pattern_miner', report)
        
        return jsonify({
            'status': 'complete',
            'batch_id': batch_id,
            'report': report,
            'next_stage': 'PENDING_GT_KEEPER'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/batch/<batch_id>/keeper', methods=['POST'])
def keeper_batch(batch_id):
    """Run GT Keeper agent on batch"""
    try:
        from database import get_batch, get_analysis
        batch_data = get_batch(app.config['DB_PATH'], batch_id)
        
        if not batch_data:
            return jsonify({'error': 'Batch not found'}), 404
        
        # Get previous analysis reports
        analyzer_report = get_analysis(app.config['DB_PATH'], batch_id, 'batch_analyzer') or {}
        pattern_report = get_analysis(app.config['DB_PATH'], batch_id, 'pattern_miner') or {}
        
        # Run GT Keeper
        keeper = GTKeeper(os.getenv('ANTHROPIC_API_KEY'))
        report = keeper.draft_update(batch_data, analyzer_report, pattern_report)
        
        from database import update_batch_status, store_analysis
        update_batch_status(app.config['DB_PATH'], batch_id, 'GT_KEEPER_COMPLETE')
        store_analysis(app.config['DB_PATH'], batch_id, 'gt_keeper', report)
        
        return jsonify({
            'status': 'complete',
            'batch_id': batch_id,
            'report': report,
            'next_stage': 'COMPLETE'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/batch/<batch_id>/status', methods=['GET'])
def batch_status(batch_id):
    """Get current batch processing status"""
    try:
        from database import get_batch_status, get_analysis
        status = get_batch_status(app.config['DB_PATH'], batch_id)
        
        analysis = {}
        if status in ['ANALYZER_COMPLETE', 'PATTERN_MINER_COMPLETE', 'GT_KEEPER_COMPLETE', 'COMPLETE']:
            analysis['analyzer'] = get_analysis(app.config['DB_PATH'], batch_id, 'batch_analyzer')
        if status in ['PATTERN_MINER_COMPLETE', 'GT_KEEPER_COMPLETE', 'COMPLETE']:
            analysis['pattern_miner'] = get_analysis(app.config['DB_PATH'], batch_id, 'pattern_miner')
        if status in ['GT_KEEPER_COMPLETE', 'COMPLETE']:
            analysis['gt_keeper'] = get_analysis(app.config['DB_PATH'], batch_id, 'gt_keeper')
        
        return jsonify({
            'batch_id': batch_id,
            'status': status,
            'analysis': analysis,
            'can_proceed': status.endswith('_COMPLETE')
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/batch/<batch_id>/approve/<stage>', methods=['POST'])
def approve_stage(batch_id, stage):
    """Approve batch to move to next stage"""
    try:
        from database import update_batch_status
        
        next_status = {
            'analyzer': 'PENDING_PATTERN_MINER',
            'pattern_miner': 'PENDING_GT_KEEPER',
            'gt_keeper': 'COMPLETE'
        }.get(stage)
        
        if not next_status:
            return jsonify({'error': 'Invalid stage'}), 400
        
        update_batch_status(app.config['DB_PATH'], batch_id, next_status)
        
        return jsonify({
            'status': 'approved',
            'batch_id': batch_id,
            'next_status': next_status
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/batches', methods=['GET'])
def list_batches():
    """List all batches with status"""
    try:
        from database import list_batches
        batches = list_batches(app.config['DB_PATH'])
        return jsonify({'batches': batches})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/')
def home():
    """Serve the unified dashboard"""
    return send_from_directory('static', 'dashboard.html')

@app.route('/pipeline')
def pipeline():
    """Serve the batch pipeline interface"""
    return send_from_directory('static', 'index.html')

@app.route('/companion.html')
@app.route('/companion')
def companion():
    """Serve the Session Companion interface"""
    return send_from_directory('static', 'companion.html')

@app.route('/<path:filename>')
def serve_static(filename):
    """Serve static files"""
    return send_from_directory('static', filename)

def parse_zip_batch(zip_path):
    """Extract CSV and screenshots from batch ZIP"""
    batch_data = {
        'events': [],
        'screenshots': {},
        'metadata': {}
    }
    
    with zipfile.ZipFile(zip_path, 'r') as zf:
        # Find and parse CSV
        csv_file = None
        for name in zf.namelist():
            if name.endswith('.csv') and 'vx' in name.lower():
                csv_file = name
                break
        
        if not csv_file:
            raise ValueError('No vX CSV file found in ZIP')
        
        # Parse CSV
        with zf.open(csv_file) as f:
            reader = csv.DictReader(StringIO(f.read().decode('utf-8')))
            batch_data['events'] = list(reader)
        
        # Infer instrument from CSV filename
        if 'NQ' in csv_file.upper():
            batch_data['metadata']['instrument'] = 'NQ'
        elif 'GC' in csv_file.upper():
            batch_data['metadata']['instrument'] = 'GC'
        else:
            batch_data['metadata']['instrument'] = 'UNKNOWN'
        
        # Index screenshots
        for name in zf.namelist():
            if name.endswith(('.png', '.jpg', '.jpeg')):
                event_id = extract_event_id_from_filename(name)
                batch_data['screenshots'][event_id] = name
        
        batch_data['metadata'] = {
            'csv_file': csv_file,
            'upload_timestamp': datetime.now().isoformat(),
            'event_count': len(batch_data['events']),
            'screenshot_count': len(batch_data['screenshots']),
            'instrument': batch_data['metadata'].get('instrument', 'UNKNOWN')
        }
    
    return batch_data

def extract_screenshots(zip_path, instrument, batch_data):
    """Extract screenshot files from ZIP to storage"""
    
    screenshot_dir = Path(app.config['SCREENSHOTS_FOLDER']) / instrument
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    
    with zipfile.ZipFile(zip_path, 'r') as zf:
        for event_id, screenshot_name in batch_data['screenshots'].items():
            try:
                # Extract file
                screenshot_data = zf.read(screenshot_name)
                
                # Save with clean filename
                ext = Path(screenshot_name).suffix
                output_path = screenshot_dir / f"{event_id}{ext}"
                
                with open(output_path, 'wb') as f:
                    f.write(screenshot_data)
            
            except Exception as e:
                print(f"Warning: Could not extract screenshot {screenshot_name}: {e}")

def extract_event_id_from_filename(filename):
    """Extract event ID from screenshot filename (e.g., NQ_E201_20260613_TRAVERSAL.png)"""
    parts = filename.split('_')
    for part in parts:
        if part.startswith('E') and part[1:].isdigit():
            return part
    return None

# ══════════════════════════════════════════════════════════════
# LAYER 1 — LIVE SESSION ENDPOINTS
# ══════════════════════════════════════════════════════════════

@app.route('/api/session/macro-events', methods=['GET'])
def get_macro_events():
    """Get today's macro events for session context"""
    # In production, fetch from calendar API or GT
    return jsonify({
        'date': datetime.now().strftime('%Y-%m-%d'),
        'events': [
            {'time': '08:30', 'event': 'US economic data release', 'impact': 'HIGH'},
            {'time': '14:00', 'event': 'Fed announcement', 'impact': 'CRITICAL'},
            {'time': '16:00', 'event': 'Market close', 'impact': 'MEDIUM'}
        ]
    })

@app.route('/api/session/windows', methods=['GET'])
def get_session_windows():
    """Get current and upcoming session windows (UTC+9)"""
    import pytz
    from datetime import datetime, time as dt_time
    
    tokyo_tz = pytz.timezone('Asia/Tokyo')
    now_tokyo = datetime.now(tokyo_tz)
    current_time = now_tokyo.time()
    
    windows = {
        'Tokyo': {'open': dt_time(7, 0), 'close': dt_time(14, 0), 'status': 'ACTIVE' if dt_time(7, 0) <= current_time < dt_time(14, 0) else 'CLOSED'},
        'London': {'open': dt_time(15, 0), 'close': dt_time(23, 0), 'status': 'ACTIVE' if dt_time(15, 0) <= current_time < dt_time(23, 0) else 'CLOSED'},
        'NY': {'open': dt_time(21, 0), 'close': dt_time(4, 0), 'status': 'ACTIVE' if current_time >= dt_time(21, 0) or current_time < dt_time(4, 0) else 'CLOSED'},
    }
    
    return jsonify({
        'current_time_utc9': now_tokyo.strftime('%H:%M'),
        'windows': windows
    })

@app.route('/api/patterns/library', methods=['GET'])
def get_pattern_library():
    """Get P1-P23 pattern reference library"""
    from agents.pattern_miner import PATTERN_LIBRARY
    
    return jsonify({
        'total_patterns': len(PATTERN_LIBRARY),
        'patterns': PATTERN_LIBRARY
    })

@app.route('/api/gt/current', methods=['GET'])
def get_current_gt():
    """Get current Ground Truth summary"""
    return jsonify({
        'version': '1.25',
        'locked_date': '2026-06-13',
        'phase': 'C',
        'status': 'ACTIVE',
        'key_rules': {
            'traversal_led': '64.4%',
            'exhaustion_led': '50.0%',
            'failed_led': '55.0%',
            'min_sample_size': 30
        }
    })

@app.route('/api/checklist/pre-session', methods=['GET'])
def get_pre_session_checklist():
    """Get pre-session checklist from GT v1.25"""
    return jsonify({
        'items': [
            {'item': 'Sampling week?', 'status': 'PENDING', 'detail': '3rd full trading week of month'},
            {'item': 'Prior batch locked?', 'status': 'PENDING', 'detail': 'Check Phase C progress'},
            {'item': 'Tagger v5.1?', 'status': 'READY', 'detail': 'Latest version active'},
            {'item': 'Instrument/timeframe?', 'status': 'PENDING', 'detail': 'NQ or GC, 5m only'},
            {'item': 'HTF channels loaded (60m/240m)?', 'status': 'PENDING', 'detail': 'For channel boundary checks'},
            {'item': 'Session windows correct (UTC+9)?', 'status': 'READY', 'detail': 'Tokyo/London/NY marked'},
            {'item': 'Macro events noted?', 'status': 'PENDING', 'detail': 'Check calendar'},
            {'item': 'GT v1.25 confirmed?', 'status': 'READY', 'detail': 'Latest version in sidebar'},
            {'item': 'Mid-window change reminder?', 'status': 'READY', 'detail': 'Flag if state changes mid-session'},
            {'item': 'DRIFT reminder?', 'status': 'READY', 'detail': 'Only tag RESEARCH_OBS'},
            {'item': 'Distortion reminder?', 'status': 'READY', 'detail': 'Rare, high bar for confirmation'},
            {'item': 'Outcome ATR reminder?', 'status': 'READY', 'detail': 'Measure MFE from signal bar close'}
        ]
    })

# ══════════════════════════════════════════════════════════════
# LAYER 3 — INTELLIGENCE STORE ENDPOINTS
# ══════════════════════════════════════════════════════════════

@app.route('/api/patterns/with-screenshots', methods=['GET'])
def get_patterns_with_screenshots():
    """Get pattern library with screenshot examples from batches"""
    from agents.pattern_miner import PATTERN_LIBRARY
    from pathlib import Path
    
    patterns = {}
    screenshot_dir = Path(app.config['SCREENSHOTS_FOLDER'])
    
    for pid, pdata in PATTERN_LIBRARY.items():
        patterns[pid] = {
            **pdata,
            'example_screenshots': []
        }
        
        # Find screenshots matching pattern (mock for now)
        if screenshot_dir.exists():
            for subdir in screenshot_dir.iterdir():
                if subdir.is_dir():
                    pngs = list(subdir.glob('*.png'))[:1]  # First screenshot
                    patterns[pid]['example_screenshots'].extend([p.name for p in pngs])
    
    return jsonify({'patterns': patterns})

@app.route('/api/events/query', methods=['POST'])
def query_events():
    """Query locked events by filters"""
    filters = request.json or {}
    
    conn = sqlite3.connect(app.config['DB_PATH'])
    c = conn.cursor()
    
    query = 'SELECT event_id, ltf_state, quality, sync, outcome_atr, tag FROM events WHERE 1=1'
    params = []
    
    if filters.get('state'):
        query += ' AND ltf_state = ?'
        params.append(filters['state'])
    
    if filters.get('session'):
        query += ' AND session = ?'
        params.append(filters['session'])
    
    if filters.get('sync'):
        query += ' AND sync = ?'
        params.append(filters['sync'])
    
    if filters.get('min_quality'):
        query += ' AND quality >= ?'
        params.append(filters['min_quality'])
    
    query += ' LIMIT 100'
    c.execute(query, params)
    
    rows = c.fetchall()
    conn.close()
    
    results = [
        {
            'event_id': r[0],
            'state': r[1],
            'quality': r[2],
            'sync': r[3],
            'outcome_atr': r[4],
            'outcome': r[5]
        }
        for r in rows
    ]
    
    return jsonify({
        'filters_applied': filters,
        'results_count': len(results),
        'results': results
    })

@app.route('/api/gt/versions', methods=['GET'])
def get_gt_versions():
    """Get Ground Truth version history"""
    return jsonify({
        'current': {
            'version': '1.25',
            'locked_date': '2026-06-13',
            'phase': 'C',
            'batches_processed': 5,
            'events_locked': 337
        },
        'history': [
            {'version': '1.24', 'date': '2026-06-08', 'changes': 'Rule clarifications, P18 confirmation'},
            {'version': '1.23', 'date': '2026-06-01', 'changes': 'TRAP_ACTIVE vs TRAP_ZONE distinction'},
            {'version': '1.22', 'date': '2026-05-25', 'changes': 'Skip window rule locked'}
        ]
    })

@app.route('/api/copilot/log-session', methods=['POST'])
def log_copilot_session():
    """Log Session Companion exchange for Co-Pilot training"""
    session_data = request.json
    
    conn = sqlite3.connect(app.config['DB_PATH'])
    c = conn.cursor()
    
    from uuid import uuid4
    
    c.execute('''INSERT INTO copilot_training 
        (id, event_id, signal_screenshot, outcome_screenshot, state, outcome, pattern_matches, session_log, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        (str(uuid4()),
         session_data.get('event_id'),
         session_data.get('signal_screenshot', ''),
         session_data.get('outcome_screenshot', ''),
         session_data.get('state', ''),
         session_data.get('outcome', ''),
         json.dumps(session_data.get('pattern_matches', [])),
         json.dumps(session_data.get('exchange', [])),
         datetime.now().isoformat())
    )
    
    conn.commit()
    conn.close()
    
    return jsonify({'status': 'logged', 'message': 'Session added to Co-Pilot training dataset'})

@app.route('/api/copilot/training-stats', methods=['GET'])
def get_copilot_stats():
    """Get Co-Pilot training data statistics"""
    conn = sqlite3.connect(app.config['DB_PATH'])
    c = conn.cursor()
    
    c.execute('SELECT COUNT(*) FROM copilot_training')
    total = c.fetchone()[0]
    
    c.execute('SELECT outcome, COUNT(*) FROM copilot_training GROUP BY outcome')
    outcome_dist = dict(c.fetchall())
    
    c.execute('SELECT state, COUNT(*) FROM copilot_training GROUP BY state')
    state_dist = dict(c.fetchall())
    
    conn.close()
    
    return jsonify({
        'total_sessions_logged': total,
        'ready_for_finetuning': total >= 100,
        'outcome_distribution': outcome_dist,
        'state_distribution': state_dist
    })

@app.route('/api/filter-test', methods=['POST'])
def test_filter():
    """Test Phase B filter on historical events"""
    filter_rule = request.json
    
    # Mock filter testing
    # In production, apply filter to event database
    
    return jsonify({
        'filter': filter_rule,
        'events_matching': 87,
        'led_rate': 0.65,
        'lift_vs_baseline': '+17 points',
        'recommendation': 'PROMISING - meets Phase B threshold'
    })

# ══════════════════════════════════════════════════════════════
# SESSION COMPANION INTEGRATION
# ══════════════════════════════════════════════════════════════

COMPANION_MODES = {
    'brief': {
        'label': 'Session Brief',
        'description': 'Calendar + macro context before you open TradingView',
        'icon': '📅'
    },
    'pattern': {
        'label': 'Pattern Analysis',
        'description': 'Upload a chart — get P1–P23 checklist + tagger note',
        'icon': '🎯'
    },
    'research': {
        'label': 'Research Log',
        'description': 'Log a RESEARCH_OBS — Drift, Rail Cycle, Liquidity Sweep',
        'icon': '🔬'
    },
    'ask': {
        'label': 'Ask Anything',
        'description': 'GT rules, patterns, decisions — direct answers',
        'icon': '❓'
    },
    'findings': {
        'label': 'Session Findings',
        'description': 'End of session — auto-format findings block for GT',
        'icon': '✓'
    },
    'audit': {
        'label': 'Tagger Audit',
        'description': 'Paste CSV data — get field error report before ZIP',
        'icon': '🔍'
    },
    'tracker': {
        'label': 'Pattern Tracker',
        'description': 'Describe what you saw — match to open questions Q-A/Q-W',
        'icon': '📊'
    },
    'journal': {
        'label': 'Decision Journal',
        'description': 'Log a methodology decision for the GT Decision Log',
        'icon': '📝'
    },
    'readiness': {
        'label': 'Phase B Readiness',
        'description': 'How close are we to Phase B go/no-go',
        'icon': '🚀'
    }
}

@app.route('/api/companion/modes', methods=['GET'])
def get_companion_modes():
    """Get available Session Companion modes"""
    return jsonify({'modes': COMPANION_MODES})

@app.route('/api/companion/chat', methods=['POST'])
def companion_chat():
    """Session Companion chat endpoint"""
    data = request.json
    user_message = data.get('message', '')
    mode = data.get('mode', 'ask')
    
    if not user_message:
        return jsonify({'error': 'Message required'}), 400
    
    api_key = os.getenv('ANTHROPIC_API_KEY')
    if not api_key:
        return jsonify({'error': 'API key not configured'}), 500
    
    try:
        client = anthropic.Anthropic(api_key=api_key)
        
        # Build mode-specific system prompt
        mode_instructions = {
            'brief': 'Provide a brief session context: macro events today, session windows, pattern reminders. Format as short blocks.',
            'pattern': 'Provide P1–P23 pattern checklist and formatted tagger note based on the chart pattern described.',
            'research': 'Format as: obs_type, note convention, pattern matches for research observations.',
            'ask': 'Answer direct GT questions about rules, patterns, decisions. Short, direct answers.',
            'findings': 'Format session findings for the GT Decision Log. Structured output only.',
            'audit': 'Report field errors, logic issues, outliers in tagger data.',
            'tracker': 'Match observations to open questions Q-A through Q-W and candidate patterns.',
            'journal': 'Format a methodology decision for the GT Decision Log.',
            'readiness': 'Calculate Phase B readiness status from current data.'
        }
        
        system_prompt = f"""You are TATAMI Session Companion — real-time partner for behavioral market analysis.

Ground Truth v1.25 is your knowledge base. You speak in:
- Short sentences, no preamble
- Numbers over prose: "Q=67 ⚠" not "quality is problematic"
- Symbols: ✓ clear · ⚠ warning · ✗ wrong
- One idea per block

{mode_instructions.get(mode, mode_instructions['ask'])}"""
        
        response = client.messages.create(
            model='claude-sonnet-4-6',
            max_tokens=1500,
            system=system_prompt,
            messages=[{'role': 'user', 'content': user_message}]
        )
        
        assistant_text = response.content[0].text
        
        return jsonify({
            'response': assistant_text,
            'mode': mode
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/companion/log', methods=['POST'])
def log_companion_session():
    """Log a Session Companion exchange for training data"""
    data = request.json
    
    session_data = {
        'timestamp': datetime.now().isoformat(),
        'mode': data.get('mode'),
        'user_message': data.get('user_message'),
        'assistant_response': data.get('assistant_response'),
        'usefulness_rating': data.get('rating')
    }
    
    # Store in database for Co-Pilot training
    conn = sqlite3.connect(app.config['DB_PATH'])
    c = conn.cursor()
    
    from uuid import uuid4
    c.execute('''INSERT INTO copilot_training 
        (id, event_id, signal_screenshot, outcome_screenshot, state, outcome, pattern_matches, session_log, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        (str(uuid4()),
         '',
         '',
         '',
         data.get('mode', ''),
         '',
         json.dumps([]),
         json.dumps(session_data),
         datetime.now().isoformat())
    )
    
    conn.commit()
    conn.close()
    
    return jsonify({'status': 'logged'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
